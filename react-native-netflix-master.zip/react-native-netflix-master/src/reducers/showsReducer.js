import data from '../data.json';
export default () => data;