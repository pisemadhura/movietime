import { AppRegistry } from 'react-native';
import IndexApp from './src/'
AppRegistry.registerComponent('NetflixApp', () => IndexApp);
